// FerBot App — pestaña externa (Bot + Dashboard)
(() => {
  const BASE_URL = "https://carly-subcerebral-nongenealogically.ngrok-free.dev";

  const qs = s => document.querySelector(s);
  const $navBot = qs("#nav_bot");
  const $navDash = qs("#nav_dash");
  const $viewBot = qs("#view_bot");
  const $viewDash = qs("#view_dash");

  // Navegación simple
  $navBot.addEventListener("click", (e) => { e.preventDefault(); setView("bot"); });
  $navDash.addEventListener("click", (e) => { e.preventDefault(); setView("dash"); });
  function setView(v) {
    [$navBot,$navDash].forEach(a => a.classList.remove("active"));
    [$viewBot,$viewDash].forEach(vw => vw.classList.remove("active"));
    if (v === "bot") { $navBot.classList.add("active"); $viewBot.classList.add("active"); }
    else { $navDash.classList.add("active"); $viewDash.classList.add("active"); }
  }

  // Bot
  const $name = qs("#name");
  const $stage = qs("#stage");
  const $text  = qs("#text");
  const $gen   = qs("#generate");
  const $clear = qs("#clear");
  const $out   = qs("#output");
  const $copy  = qs("#copy");

  // recuerda nombre
  const LS_NAME = "ferbot_customer_name";
  try { $name.value = JSON.parse(localStorage.getItem(LS_NAME)) ?? ""; } catch {}
  $name.addEventListener("input", () => localStorage.setItem(LS_NAME, JSON.stringify($name.value.trim())));

  $gen.addEventListener("click", async () => {
    const question = ($text.value || "").trim();
    const customerName = ($name.value || "").trim();
    const stage = $stage.value;
    if (!question) { $out.textContent = "Escribe una objeción."; return; }
    $gen.disabled = true; const prev = $gen.textContent; $gen.textContent = "Generando…";
    try {
      const r = await fetch(`${BASE_URL}/assist`, {
        method: "POST",
        headers: {"Content-Type":"application/json"},
        body: JSON.stringify({ question, customerName, stage })
      });
      const j = await r.json().catch(()=> ({}));
      if (!r.ok || !j.ok) throw new Error(j?.error || `HTTP ${r.status}`);
      const txt = j?.result?.sections?.[stage] || j?.result?.message || "Sin texto.";
      $out.textContent = txt.trim();
    } catch(e) {
      $out.textContent = `⚠️ ${String(e.message||e)}`;
    } finally {
      $gen.disabled = false; $gen.textContent = prev;
    }
  });

  $clear.addEventListener("click", () => { $text.value=""; $out.textContent=""; $text.focus(); });
  $copy.addEventListener("click", async () => {
    const t = ($out.textContent||"").trim(); if (!t) return;
    try { await navigator.clipboard.writeText(t); $copy.textContent="Copiado ✅"; setTimeout(()=> $copy.textContent="Copiar", 900); } catch {}
  });

  // Dashboard
  const $refresh = qs("#refresh");
  const $status  = qs("#status");
  const $grid    = qs("#grid");

  async function refreshDash() {
    $status.textContent = "Cargando…"; $grid.innerHTML = "";
    try {
      const r = await fetch(`${BASE_URL}/stats`);
      const d = await r.json();
      if (!d?.ok) throw new Error("Stats no disponibles");
      $status.textContent = "";
      addStat("Memoria", String(d.memory_count ?? 0));
      addStat("Assist (últimos)", String(d.assist_calls_last200 ?? 0));
      // Top tags
      const tags = d.tags || {};
      const sorted = Object.entries(tags).sort((a,b)=>b[1]-a[1]).slice(0,6);
      const list = sorted.length ? sorted.map(([k,v]) => `<li><strong>${k}</strong> · ${v}</li>`).join("") : "<li>—</li>";
      const el = document.createElement("div");
      el.className = "stat"; el.innerHTML = `<div class="t">Top tags</div><ul class="tags">${list}</ul>`;
      $grid.appendChild(el);
    } catch(e) {
      $status.textContent = `⚠️ ${String(e.message||e)}`;
    }
  }
  function addStat(title, value) {
    const el = document.createElement("div");
    el.className = "stat";
    el.innerHTML = `<div class="t">${title}</div><div class="v">${value}</div>`;
    $grid.appendChild(el);
  }
  $refresh.addEventListener("click", refreshDash);

  // inicial
  setView("bot");
  refreshDash();
})();
