chrome.runtime.onInstalled.addListener(() => {
  // nada por ahora, solo para MV3
});
